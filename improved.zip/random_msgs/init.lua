
minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#6aff57", "|TIP| If you are ever stuck some time, do /spawn to teleport to the spawn or place where you started\n"))
	end
	minetest.after(320, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#5a97fa", "|Did you know?| You can turn on pvp by typing the command: /toggle_pvp\n"))
	end
	minetest.after(500, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#cc0000", "|Warning| Always follow the rules or you might be kicked, banned or get your privs revoked\n"))
	end
	minetest.after(709, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#7452d1", "|Discord| Join our discord server, so you can be in our community! discord: https://discord.gg/YTx7rKra\n"))
	end
	minetest.after(800, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#6aff57", "|TIP| If you are ever stuck some time, do /spawn to teleport to the spawn or place where you started\n"))
	end
	minetest.after(1103, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#5a97fa", "|Did you know?| You can turn on pvp by typing the command: /toggle_pvp\n"))
	end
	minetest.after(1300, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#cc0000", "|Warning| Always follow the rules or you might be kicked, banned or get your privs revoked\n"))
	end
	minetest.after(1509, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#7452d1", "|Discord| Join our discord server, so you can be in our community! discord: https://discord.gg/YTx7rKra\n"))
	end
	minetest.after(1620, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#56f0f0", "Welcome to Dark Caves WildSurvival. We hope you enjoy playing and make lots of new friends!!! \n"))
	end
	minetest.after(3, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#6aff57", "|TIP| If you are ever stuck some time, do /spawn to teleport to the spawn or place where you started\n"))
	end
	minetest.after(2723, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#5a97fa", "|Did you know?| You can turn on pvp by typing the command: /toggle_pvp\n"))
	end
	minetest.after(2920, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#cc0000", "|Warning| Always follow the rules or you might be kicked, banned or get your privs revoked\n"))
	end
	minetest.after(3129, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#7452d1", "|Discord| Join our discord server, so you can be in our community! discord: https://discord.gg/YTx7rKra\n"))
	end
	minetest.after(3240, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#6aff57", "|TIP| If you are ever stuck some time, do /spawn to teleport to the spawn or place where you started\n"))
	end
	minetest.after(3523, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#5a97fa", "|Did you know?| You can turn on pvp by typing the command: /toggle_pvp\n"))
	end
	minetest.after(3720, cb, player)
end)


minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#cc0000", "|Warning| Always follow the rules or you might be kicked, banned or get your privs revoked\n"))
	end
	minetest.after(3929, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#7452d1", "|Discord| Join our discord server, so you can be in our community! discord: https://discord.gg/YTx7rKra\n"))
	end
	minetest.after(4040, cb, player)
end)

minetest.register_on_joinplayer(function(player)
	player:set_properties({physical = false})
end)

minetest.register_on_joinplayer(function(player)
	local cb = function(player)
		if not player or not player:is_player() then
			return
		end
		minetest.chat_send_player(player:get_player_name(), minetest.colorize("#f6fc47", "|Did you know| You can do /afk and /back to warn everyone that you are afk or you are back from afk\n"))
	end
	minetest.after(200, cb, player)
end)

