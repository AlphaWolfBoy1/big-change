# AFK Chatcommand

Adds /afk and /back to your minetest server!
A mod thats lets you go AFK with a command! (Code provided by IhrFussel and modified by Koda)


## Installation 

- Unzip the archive, rename the folder to `afk_command` and
place it in .. minetest/mods/

- GNU/Linux: If you use a system-wide installation place
    it in ~/.minetest/mods/.

- If you only want this to be used in a single world, place
    the folder in .. worldmods/ in your world directory.

For further information or help, see:\
<https://wiki.minetest.net/Installing_Mods>

## Dependencies

- `default` (included in [Minetest Game](https://github.com/minetest/minetest_game))
